subscription.invoice
subscription.invoice.transaction
subscription.invoice.transaction.amount
subscription.invoice.transaction.response
subscription.invoice.transaction.gatewayToken
subscription.invoice.invoiceNumber
subscription.invoice.charges




{
    "subscription": {
        "invoice":{
            "BillingDateTime": "\/Date(1614001261000)\/",
            "transaction":{
              "amount":"",
            }
            "charges":[

            ]

        }
    }
}
